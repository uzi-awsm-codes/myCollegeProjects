create table if not exists subject(subcode varchar(10) primary key, sem int, branch varchar(5), subject_name varchar(20), scheme int);

create table if not exists notes(subcode varchar(10), foreign key(subcode) references subject(subcode) on delete cascade on update cascade, faculty varchar(20), college varchar(30), notes longtext);

create table if not exists textbook(subcode varchar(10), foreign key(subcode) references subject(subcode) on delete cascade on update cascade, author varchar(20), textbookname varchar(30),textbook longtext);

create table if not exists questionpapers(subcode varchar(10), foreign key(subcode) references subject(subcode) on delete cascade on update cascade, year int, month varchar(3),questionpapers longtext);

create table if not exists syllabus(subcode varchar(10), foreign key(subcode) references subject(subcode) on delete cascade on update cascade, scheme int,syllabus longtext);

create table if not exists admin(username varchar(20), password varchar(10));

