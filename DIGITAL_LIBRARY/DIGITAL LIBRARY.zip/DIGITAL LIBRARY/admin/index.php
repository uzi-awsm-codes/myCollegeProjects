<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");
?>


<!DOCTYPE html>
<html>
<head>
	<title>Digital library Admin</title>
</head>
<body>

	<h1 align="center">welcome to digital library admin panel</h1>
	<h3>choose any of below table to view its content</h3>



	<form action="all.php" method="POST" enctype="multipart/form-data">
	<input type="submit" name="all" value="all table">
	</form>


	<form action="subject.php" method="POST" enctype="multipart/form-data">
	<input type="submit" name="subject" value="subject table">
	</form>




	<!--<form action="notes.php" method="POST" enctype="multipart/form-data">
	<input type="submit" name="notes" value="notes table">
	</form>


	<a href="textbook.php"> textbook table </a><br>
	<a href="questionpapers.php"> questionpapers table </a><br>
	<a href="syllubus.php"> syllubus table </a> -->

















</body>
</html>