<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");

?>

<!DOCTYPE html>
<html>
<head>
	<title>Digital library Admin</title>
</head>
<body bgcolor="#726bb6">

<a href="index.php"> home </a>



<?php


	 if(isset($_POST["all"]))    
	 {
	    
	    $subject=mysqli_query($list,"select * from subject;");
	    echo "<h1 align=center> content of subject table</h1>";
	  	echo "<table align=center>";

	    	echo "<tr>";
	            echo "<th>";  echo "subcode"; echo "</th>";
	             echo "<th>";  echo "sem"; echo "</th>";
	              echo "<th>";  echo "branch"; echo "</th>";
	               echo "<th>";  echo "subject_name"; echo "</th>";
	                echo "<th>";  echo "scheme"; echo "</th>";
	           
	        echo "</tr>";   




	    	while($subject1=mysqli_fetch_assoc($subject))
	    	{
	        	echo "<tr>";
	           		 echo "<td>";   echo $subject1["subcode"]; echo "</td>";
	           		  echo "<td>";   echo $subject1["sem"]; echo "</td>";
	           		   echo "<td>";   echo $subject1["branch"]; echo "</td>";
	           		    echo "<td>";   echo $subject1["subject_name"]; echo "</td>";
	           		     echo "<td>";   echo $subject1["scheme"]; echo "</td>"; 
	           		 
	           		 
	           		
	        	echo "</tr>";        
	   		}
	    echo "</table>";

	    
	}



?>

		
	<h3>enter value to insert into subject table</h3>

	<form action="" method="POST" enctype="multipart/form-data">
        <table>
            
            <tr>
                <td>subject code</td>
                <td><input type="text" name="subcode" required></td>
            </tr>
        
        
            <tr>
                <td>sem</td>
                <td><input type="text" name="sem" required ></td>
            </tr>    
        

            <tr>
                <td>branch</td>
                <td><input type="text" name="branch" required></td>
            </tr>  


            <tr>
                <td>subject name</td>
                <td><input type="text" name="subject_name" required ></td>
            </tr>  


            <tr>
                <td>scheme</td>
                <td><input type="text" name="scheme" required ></td>
            </tr>  






            <tr>
                <td align=center>
                	<input type="submit" name="subject" value="insert">
    			</td>
            </tr>  
            
            
            
        </table>
    </form>
	
<?php
    
    if(isset($_POST["subject"]))
    {
      
        mysqli_query($list,"INSERT INTO `subject`(`subcode`, `sem`, `branch`, `subject_name`, `scheme`) VALUES ('$_POST[subcode]','$_POST[sem]','$_POST[branch]','$_POST[subject_name]','$_POST[scheme]');");
    }	



?>

<?php

    if(isset($_POST["all"]))    
    {
    
        $notes=mysqli_query($list,"select * from notes");
        echo "<h1 align=center> content of notes table</h1>";
        echo "<table align=center>";
        echo "<tr>";
            echo "<th>";  echo "subcode"; echo "</th>";
             echo "<th>";  echo "faculty"; echo "</th>";
              echo "<th>";  echo "collage"; echo "</th>";
               echo "<th>";  echo "notes"; echo "</th>";
        echo "</tr>";  





        while($notes1=mysqli_fetch_assoc($notes))
        {
        echo "<tr>";
            echo "<td>";  echo $notes1["subcode"];  echo "</td>";
             echo "<td>";  echo $notes1["faculty"];  echo "</td>";
               echo "<td>";  echo $notes1["college"];  echo "</td>";
                echo "<td>"; echo '<a href="../'.$notes1["notes"].'"> view </a>'; echo $notes1["notes"]; echo "</td>";
        echo "</tr>";        
        }
        echo "</table>";

    
    }



?>









<h3>enter value to insert into notes table</h3>

    <form action="" method="POST" enctype="multipart/form-data">
        <table>
            
            <tr>
                <td>subject code</td>
                <td><input type="text" name="subcode" required></td>
            </tr>
        
        
            <tr>
                <td>faculty</td>
                <td><input type="text" name="faculty" required ></td>
            </tr>    
        

            <tr>
                <td>collage</td>
                <td><input type="text" name="collage" required></td>
            </tr>  


            <tr>
                <td>notes</td>
                <td><input type="file" name="notes" required ></td>
            </tr> 


            <tr>
                <td align=center>
                    <input type="submit" name="note" value="insert">
                </td>
            </tr>  
            
            
            
        </table>
    </form>

<?php

    if(isset($_POST["note"]))
    {
        move_uploaded_file($_FILES['notes']['tmp_name'],"../uploaded_pdf/".$_FILES['notes']['name']);
        $pdf = "uploaded_pdf/".$_FILES['notes']['name']; 
        mysqli_query($list,"INSERT INTO `notes`(`subcode`, `faculty`, `college`, `notes`) VALUES ('$_POST[subcode]','$_POST[faculty]','$_POST[collage]','$pdf');");
    }   



?>



<?php

    if(isset($_POST["all"]))    
    {
    
        $textbook=mysqli_query($list,"select * from textbook");
        echo "<h1 align=center> content of textbook table</h1>";
        echo "<table align=center>";
        echo "<tr>";
            echo "<th>";  echo "subcode"; echo "</th>";
             echo "<th>";  echo "author"; echo "</th>";
              echo "<th>";  echo "textbookname"; echo "</th>";
               echo "<th>";  echo "textbook"; echo "</th>";
        echo "</tr>";  





        while($textbook1=mysqli_fetch_assoc($textbook))
        {
        echo "<tr>";
            echo "<td>";  echo $textbook1["subcode"];  echo "</td>";
             echo "<td>";  echo $textbook1["author"];  echo "</td>";
               echo "<td>";  echo $textbook1["textbookname"];  echo "</td>";
                echo "<td>"; echo '<a href="../'.$textbook1["textbook"].'"> view </a>'; echo $textbook1["textbook"]; echo "</td>";
        echo "</tr>";        
        }
        echo "</table>";

    
    }



?>


    <h3>enter value to insert into textbook table</h3>

    <form action="" method="POST" enctype="multipart/form-data">
        <table>
            
            <tr>
                <td>subject code</td>
                <td><input type="text" name="subcode" required></td>
            </tr>
        
        
            <tr>
                <td>author</td>
                <td><input type="text" name="author" required ></td>
            </tr>    
        

            <tr>
                <td>textbook name</td>
                <td><input type="text" name="textbookname" required></td>
            </tr>  


            <tr>
                <td>textbook </td>
                <td><input type="file" name="textbook" required ></td>
            </tr> 


            <tr>
                <td align=center>
                    <input type="submit" name="textbook" value="insert">
                </td>
            </tr>  
            
            
            
        </table>
    </form>


<?php

    if(isset($_POST["textbook"]))
    {
        move_uploaded_file($_FILES['textbook']['tmp_name'],"../uploaded_pdf/".$_FILES['textbook']['name']);
        $pdf = "uploaded_pdf/".$_FILES['textbook']['name']; 
        mysqli_query($list,"INSERT INTO `textbook`(`subcode`, `author`, `textbookname`, `textbook`) VALUES ('$_POST[subcode]','$_POST[author]','$_POST[textbookname]','$pdf');");
    }   



?>






<?php

    if(isset($_POST["all"]))    
    {
    
        $question=mysqli_query($list,"select * from questionpapers");
        echo "<h1 align=center> content of question paper table</h1>";
        echo "<table align=center>";
        echo "<tr>";
            echo "<th>";  echo "subcode"; echo "</th>";
             echo "<th>";  echo "year"; echo "</th>";
              echo "<th>";  echo "month"; echo "</th>";
               echo "<th>";  echo "question paper"; echo "</th>";
        echo "</tr>";  





        while($question1=mysqli_fetch_assoc($question))
        {
        echo "<tr>";
            echo "<td>";  echo $question1["subcode"];  echo "</td>";
             echo "<td>";  echo $question1["year"];  echo "</td>";
               echo "<td>";  echo $question1["month"];  echo "</td>";
                echo "<td>"; echo '<a href="../'.$question1["questionpapers"].'"> view </a>'; echo $question1["questionpapers"]; echo "</td>";
        echo "</tr>";        
        }
        echo "</table>";

    
    }


?>










<h3>enter value to insert into question paper table</h3>

    <form action="" method="POST" enctype="multipart/form-data">
        <table>
            
            <tr>
                <td>subject code</td>
                <td><input type="text" name="subcode" required></td>
            </tr>
        
        
            <tr>
                <td>year</td>
                <td><input type="text" name="year" required ></td>
            </tr>    
        

            <tr>
                <td>month</td>
                <td><input type="text" name="month" required></td>
            </tr>  


            <tr>
                <td>question paper  </td>
                <td><input type="file" name="question" required ></td>
            </tr> 


            <tr>
                <td align=center>
                    <input type="submit" name="question" value="insert">
                </td>
            </tr>  
            
            
            
        </table>
    </form>





<?php

    if(isset($_POST["question"]))
    {
        move_uploaded_file($_FILES['question']['tmp_name'],"../uploaded_pdf/".$_FILES['question']['name']);
        $pdf = "uploaded_pdf/".$_FILES['question']['name']; 
        mysqli_query($list,"INSERT INTO `questionpapers`(`subcode`, `year`, `month`, `questionpapers`) VALUES ('$_POST[subcode]','$_POST[year]','$_POST[month]','$pdf');");
    }   



?>






<?php

    if(isset($_POST["all"]))    
    {
    
        $syllabus=mysqli_query($list,"select * from syllabus");
        echo "<h1 align=center> content of syllabus table</h1>";
        echo "<table align=center>";
        echo "<tr>";
            echo "<th>";  echo "subcode"; echo "</th>";
             echo "<th>";  echo "scheme"; echo "</th>";
              echo "<th>";  echo "syllabus"; echo "</th>";
        echo "</tr>";  





        while($syllabus1=mysqli_fetch_assoc($syllabus))
        {
        echo "<tr>";
            echo "<td>";  echo $syllabus1["subcode"];  echo "</td>";
             echo "<td>";  echo $syllabus1["scheme"];  echo "</td>";
                echo "<td>"; echo '<a href="../'.$syllabus1["syllabus"].'"> view </a>'; echo $syllabus1["syllabus"]; echo "</td>";
        echo "</tr>";        
        }
        echo "</table>";

    
    }



?>






<h3>enter value to insert into syllabus table</h3>

    <form action="" method="POST" enctype="multipart/form-data">
        <table>
            
            <tr>
                <td>subject code</td>
                <td><input type="text" name="subcode" required></td>
            </tr>
        
        
             
        

            <tr>
                <td>scheme</td>
                <td><input type="text" name="scheme" required></td>
            </tr>  


            <tr>
                <td>syllabus  </td>
                <td><input type="file" name="syllabus" required ></td>
            </tr> 


            <tr>
                <td align=center>
                    <input type="submit" name="syllabus" value="insert">
                </td>
            </tr>  
            
            
            
        </table>
    </form>


<?php

    if(isset($_POST["syllabus"]))
    {
        move_uploaded_file($_FILES['syllabus']['tmp_name'],"../uploaded_pdf/".$_FILES['syllabus']['name']);
        $pdf = "uploaded_pdf/".$_FILES['syllabus']['name']; 
        mysqli_query($list,"INSERT INTO `syllabus`(`subcode`, `scheme`, `syllabus`) VALUES ('$_POST[subcode]','$_POST[scheme]','$pdf');");
    }   

    
?>








</body>
</html>