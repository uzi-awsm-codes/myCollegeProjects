<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");

?>

<!DOCTYPE html>
<html>
<head>
	<title>Digital library Admin</title>
</head>
<body>





<?php


	 if(isset($_POST["subject"]))    
	 {
	    
	    $ress=mysqli_query($list,"select * from subject;");
	    echo "<h1 align=center> content of subject table</h1>";
	  	echo "<table align=center>";

	    	echo "<tr>";
	            echo "<th>";  echo "subcode"; echo "</th>";
	             echo "<th>";  echo "sem"; echo "</th>";
	              echo "<th>";  echo "branch"; echo "</th>";
	               echo "<th>";  echo "subject_name"; echo "</th>";
	                echo "<th>";  echo "scheme"; echo "</th>";
	           
	        echo "</tr>";   




	    	while($row1=mysqli_fetch_assoc($ress))
	    	{
	        	echo "<tr>";
	           		 echo "<td>";   echo $row1["subcode"]; echo "</td>";
	           		  echo "<td>";   echo $row1["sem"]; echo "</td>";
	           		   echo "<td>";   echo $row1["branch"]; echo "</td>";
	           		    echo "<td>";   echo $row1["subject_name"]; echo "</td>";
	           		     echo "<td>";   echo $row1["scheme"]; echo "</td>"; 
	           		 
	           		 
	           		
	        	echo "</tr>";        
	   		}
	    echo "</table>";

	    
	}



?>

		
	<h3>enter value to insert into table</h3>

	<form action="" method="POST" enctype="multipart/form-data">
        <table>
            
            <tr>
                <td>subject code</td>
                <td><input type="text" name="subcode" required></td>
            </tr>
        
        
            <tr>
                <td>sem</td>
                <td><input type="text" name="sem" required ></td>
            </tr>    
        

            <tr>
                <td>branch</td>
                <td><input type="text" name="branch" required></td>
            </tr>  


            <tr>
                <td>subject name</td>
                <td><input type="text" name="subject_name" required ></td>
            </tr>  


            <tr>
                <td>scheme</td>
                <td><input type="text" name="scheme" required ></td>
            </tr>  






            <tr>
                <td align=center>
                	<input type="submit" name="submit" value="insert">
    			</td>
            </tr>  
            
            
            
        </table>
    </form>
	
<?php
    
    if(isset($_POST["submit"]))
    {
      
        mysqli_query($list,"INSERT INTO `subject`(`subcode`, `sem`, `branch`, `subject_name`, `scheme`) VALUES ('$_POST[subcode]','$_POST[sem]','$_POST[branch]','$_POST[subject_name]','$_POST[scheme]');");
    }	



?>














</body>
</html>