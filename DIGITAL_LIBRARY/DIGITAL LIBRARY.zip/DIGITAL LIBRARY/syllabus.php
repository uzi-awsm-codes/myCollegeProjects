<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");

    session_start();
	$name=$_SESSION['myValue'];


	if(isset($_POST["syllabus"]))    
    {
    
        $syllabus=mysqli_query($list,"select * from syllabus where subcode='$name'");

        $count= mysqli_num_rows($syllabus);
        if($count== 0)
        {    
            echo "currently syllabus is not avaliable for $name";

            


        }
        else
        {





            
        






	        echo "<h1 align=center> avliable syllabus are </h1>";
	        echo "<table align=center>";
	        echo "<tr>";
	            echo "<th>";  echo "subcode"; echo "</th>";
	             echo "<th>";  echo "scheme"; echo "</th>";
	              echo "<th>";  echo "syllabus"; echo "</th>";
	        echo "</tr>";  





	        while($syllabus1=mysqli_fetch_assoc($syllabus))
	        {
	        echo "<tr>";
	            echo "<td>";  echo $syllabus1["subcode"];  echo "</td>";
	             echo "<td>";  echo $syllabus1["scheme"];  echo "</td>";
	                echo "<td>"; echo '<a href="'.$syllabus1["syllabus"].'"> view </a>'; echo $syllabus1["syllabus"]; echo "</td>";
	        echo "</tr>";        
	        }
	        echo "</table>";

    
   		}


	}



?>