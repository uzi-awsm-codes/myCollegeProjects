<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");
?>


<!DOCTYPE html>
<html>
<head>
	<title>digital library</title>
</head>
<body>

	<h3>choose any type you want</h3>

	<form action="notes.php" method="POST" enctype="multipart/form-data">
	<input type="submit" name="notes" value="notes">
	</form>

	<form action="textbook.php" method="POST" enctype="multipart/form-data">
	<input type="submit" name="textbook" value="textbook">
	</form>

	<form action="question.php" method="POST" enctype="multipart/form-data">
	<input type="submit" name="question" value="questionpapers">
	</form>

	<form action="syllabus.php" method="POST" enctype="multipart/form-data">
	<input type="submit" name="syllabus" value="syllabus">
	</form>





</body>
</html>