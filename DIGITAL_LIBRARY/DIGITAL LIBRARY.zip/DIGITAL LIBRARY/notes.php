<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");

    session_start();
	$name=$_SESSION['myValue'];


    if(isset($_POST["notes"]))    
    {
    
        $notes=mysqli_query($list,"select * from notes where subcode='$name'");
        $count= mysqli_num_rows($notes);
        if($count== 0)
        {    
            echo "currently syllabus is not avaliable for $name";

            


        }
        else
        {
	        echo "<h1 align=center> avaliable notes are </h1>";
	        echo "<table align=center>";
	        echo "<tr>";
	            echo "<th>";  echo "subcode"; echo "</th>";
	             echo "<th>";  echo "faculty"; echo "</th>";
	              echo "<th>";  echo "collage"; echo "</th>";
	               echo "<th>";  echo "notes"; echo "</th>";
	        echo "</tr>";  





	        while($notes1=mysqli_fetch_assoc($notes))
	        {
	        echo "<tr>";
	            echo "<td>";  echo $notes1["subcode"];  echo "</td>";
	             echo "<td>";  echo $notes1["faculty"];  echo "</td>";
	               echo "<td>";  echo $notes1["college"];  echo "</td>";
	                echo "<td>"; echo '<a href="'.$notes1["notes"].'"> view </a>'; echo $notes1["notes"]; echo "</td>";
	        echo "</tr>";        
	        }
	        echo "</table>";
	    }    
        
    
    }
?>    