<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");


    session_start();
    







    if(isset($_POST["submit5"]))    
    {
        $r=mysqli_query($list,"select * from subject where subcode ='$_POST[subcode]';");   
        
        $name = filter_input(INPUT_POST, 'subcode');
        $_SESSION['myValue']=$name;
        $count= mysqli_num_rows($r);
        if($count== 0)
        {    
            echo "$name subject code not found in our database";


            

        }
        else
        {

                        echo "your requested subject code study material is found"; 
                        echo "<br/>";
                        echo '<a href="detail.php">click here</a>'; echo " to view the alvailable notes,question,textbook and syllubus for sujectcode $name";
                        


            
            

        }
    }    
?>    

