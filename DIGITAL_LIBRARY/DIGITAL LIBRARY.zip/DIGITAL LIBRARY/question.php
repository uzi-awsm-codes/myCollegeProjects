<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");

    session_start();
	$name=$_SESSION['myValue'];

	if(isset($_POST["question"]))    
    {
    
        $question=mysqli_query($list,"select * from questionpapers where subcode='$name'");



        $count= mysqli_num_rows($question);
        if($count== 0)
        {    
            echo "currently syllabus is not avaliable for $name";

            


        }
        else
        {
        	echo "<h1 align=center> avaliable questionpapers are </h1>";
	        echo "<table align=center>";
	        echo "<tr>";
	            echo "<th>";  echo "subcode"; echo "</th>";
	             echo "<th>";  echo "year"; echo "</th>";
	              echo "<th>";  echo "month"; echo "</th>";
	               echo "<th>";  echo "question paper"; echo "</th>";
	        echo "</tr>";  





	        while($question1=mysqli_fetch_assoc($question))
	        {
	        echo "<tr>";
	            echo "<td>";  echo $question1["subcode"];  echo "</td>";
	             echo "<td>";  echo $question1["year"];  echo "</td>";
	               echo "<td>";  echo $question1["month"];  echo "</td>";
	                echo "<td>"; echo '<a href="'.$question1["questionpapers"].'"> view </a>'; echo $question1["questionpapers"]; echo "</td>";
	        echo "</tr>";        
	        }
	        echo "</table>";

    	}
    }


?>
