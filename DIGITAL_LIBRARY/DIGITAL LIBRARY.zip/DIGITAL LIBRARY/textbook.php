<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");

    session_start();
	$name=$_SESSION['myValue'];

	if(isset($_POST["textbook"]))    
    {
    
        $textbook=mysqli_query($list,"select * from textbook where subcode='$name'");
        $count= mysqli_num_rows($textbook);
        if($count== 0)
        {    
            echo "currently syllabus is not avaliable for $name";

            


        }
        else
        {

	        echo "<h1 align=center> avalaible textbook are</h1>";
	        echo "<table align=center>";
	        echo "<tr>";
	            echo "<th>";  echo "subcode"; echo "</th>";
	             echo "<th>";  echo "author"; echo "</th>";
	              echo "<th>";  echo "textbookname"; echo "</th>";
	               echo "<th>";  echo "textbook"; echo "</th>";
	        echo "</tr>";  





	        while($textbook1=mysqli_fetch_assoc($textbook))
	        {
	        echo "<tr>";
	            echo "<td>";  echo $textbook1["subcode"];  echo "</td>";
	             echo "<td>";  echo $textbook1["author"];  echo "</td>";
	               echo "<td>";  echo $textbook1["textbookname"];  echo "</td>";
	                echo "<td>"; echo '<a href="'.$textbook1["textbook"].'"> view </a>'; echo $textbook1["textbook"]; echo "</td>";
	        echo "</tr>";        
	        }
	        echo "</table>";
	    }    
    }
    
?>       