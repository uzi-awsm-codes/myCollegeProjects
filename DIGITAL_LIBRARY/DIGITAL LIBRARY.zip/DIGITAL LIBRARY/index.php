<?php
    $host = "localhost";
    $dbusername = "root";
    $list=mysqli_connect($host,$dbusername,"");
    mysqli_select_db($list,"digital_library");
?>










<!DOCTYPE html>
<html>
<head>
	<title>Digital library</title>
</head>
<body>
		<h1>welcome to digital library</h1>
		<form action="search.php" method="POST" enctype="multipart/form-data">
				<table>
					<tr>
						<td><h3>enter subject code</h3></td>
						<td><input type="text" name="subcode"> </td>
						<td> <input type="submit" name="submit5" value="search"> </td>
					</tr>
				</table>
		<form>
</body>
</html>