from tkinter.ttk import *
from tkinter import *
from PIL import ImageTk,Image
from tkinter import filedialog
from tkinter import messagebox
from openpyxl import Workbook
from openpyxl import load_workbook
import os
import pymysql

#frame5 6
import anotes as notes

import atextbook as textbook

import aquestionpapers as questionpapers

import asyllabus as syllabus


def pnt10(window,frame1):
        subject(window,frame1)

def frame(frame5)  :
    frame5.tkraise()
      
def subject(window,frame1):
    
    def insert():
        a=entry1.get()
        b=entry2.get()
        c=entry3.get()
        d=entry4.get()
        e=entry5.get()
        
        conn=pymysql.connect(host="localhost",user="root",password="",db="digital_library")
        cursor=conn.cursor()
        sql="INSERT INTO subject(subcode,sem,branch,subject_name,scheme) values(%s,%s,%s,%s,%s)"
        cursor.execute(sql,(a,b,c,d,e))
        conn.commit()
        entry1.delete(0,END) 
        entry2.delete(0,END)
        entry3.delete(0,END)
        entry4.delete(0,END)
        entry5.delete(0,END)
        pnt10(window,frame1)
    
    def logout():
        frame1.tkraise()
    
    frame5=Frame(window)
    frame5.place(relwidth=1,relheight=1)
    
    def delete(a):
                
                conn=pymysql.connect(host="localhost",user="root",password="",db="digital_library")
                cursor=conn.cursor()
                sql="delete from subject where subcode=(%s);"
                cursor.execute(sql,(a))
                conn.commit()
                pnt10(window,frame1)
            
    def pnt1():
        
            lsubcode=Label(frame5,text="subcode",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
            lsubcode.place(relwidth=0.1,relheight=0.03,relx=0.3,rely=0.27,anchor="n")
            
            lsem=Label(frame5,text="sem",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
            lsem.place(relwidth=0.1,relheight=0.03,relx=0.4,rely=0.27,anchor="n")
            
            lbranch=Label(frame5,text="branch",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
            lbranch.place(relwidth=0.1,relheight=0.03,relx=0.5,rely=0.27,anchor="n")
            
            lsubjectname=Label(frame5,text="subject name",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
            lsubjectname.place(relwidth=0.1,relheight=0.03,relx=0.6,rely=0.27,anchor="n")
            
            lschema=Label(frame5,text="schema",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
            lschema.place(relwidth=0.1,relheight=0.03,relx=0.7,rely=0.27,anchor="n")
            
            conn=pymysql.connect(host="localhost",user="root",password="",db="digital_library")
            cursor=conn.cursor()
            sql="select * from subject;"
            cursor.execute(sql)
            d=cursor.fetchall()
            conn.commit()
            le=len(d)
            if le<=15:
                l=0
                for i in range(le):
                    for j in range(5):
                        lsubcode=Label(frame5,text=d[i][j],background="black",foreground="white",width=10,font=("Glasgow Heavy",12),relief="ridge")
                        lsubcode.place(relwidth=0.1,relheight=0.03,relx=0.3+(j*0.1),rely=0.3+(i*0.03),anchor="n")
                    l=l+1
                if l!=0: 
                    bdelete=Button(frame5,text="delete",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",12),relief="ridge",command=lambda:delete(d[l-1][0]))
                    bdelete.place(relwidth=0.1,relheight=0.03,relx=0.8,rely=0.3+((l-1)*0.03),anchor="n")    
                    
                
                
                        
            else:
                for i in range(le):
                    for j in range(5):
                        
                        def next1(k):
                            frame6=Frame(window)
                            frame6.place(relwidth=0.6,relheight=0.5,relx=0.25,rely=0.3)
                            
                            img5=ImageTk.PhotoImage(Image.open("b1.jpg"))
                            limg5=Label(frame6,image=img5)
                            limg5.place(relwidth=1,relheight=1)
                            l=0
                            m=le-k
                            for i in range((le-k),le):
                                m=m+1
                                l=l+1
                                for j in range(5):
                                     lsubcode=Label(frame6,text=d[i][j],background="black",foreground="white",width=20,font=("Glasgow Heavy",12),relief="ridge")
                                     lsubcode.place(relwidth=0.167,relheight=0.06,relx=0.082+(j*0.167),rely=0.00+((i-15)*0.06),anchor="n")
                                     bback=Button(frame6,text="back",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",12),relief="ridge",command=lambda:frame(frame5))
                                     bback.place(relwidth=0.167,relheight=0.06,relx=0.5,rely=0.94,anchor="n")
                
                            if m!=0:
                                bdelete=Button(frame6,text="delete",background="#ff9f00",foreground="white",width=10,font=("Glasgow Heavy",12),relief="ridge",command=lambda:delete(d[m-1][0]))
                                bdelete.place(relwidth=0.167,relheight=0.06,relx=0.917,rely=0.00+((l-1)*0.06),anchor="n")  
                            frame6.mainloop()
                        if i<15:
                            lsubcode=Label(frame5,text=d[i][j],background="black",foreground="white",width=10,font=("Glasgow Heavy",12),relief="ridge")
                            lsubcode.place(relwidth=0.1,relheight=0.03,relx=0.3+(j*0.1),rely=0.3+(i*0.03),anchor="n")
                            bnext=Button(frame5,text="next",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",12),relief="ridge",command=lambda:next1(le-15))
                            bnext.place(relwidth=0.1,relheight=0.03,relx=0.5,rely=0.75,anchor="n")
                            
                   
    img4=ImageTk.PhotoImage(Image.open("b1.jpg"))
    limg4=Label(frame5,image=img4)
    limg4.place(relwidth=1,relheight=1)
    
    lheader1=Label(frame5, text="WELCOME TO DIGITAL LIBRARY ADMIN PANEL", font=("Times New Roman",30), relief="solid")
    lheader1.place(relx=0.5,rely=0.06,anchor="n")
    
    
    bsubject=Button(frame5,text="subject",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=pnt1)
    bsubject.place(relwidth=0.15,relheight=0.04,relx=0.2,rely=0.20,anchor="n")
    
    bnotes=Button(frame5,text="notes",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:notes.notes(window,frame1))
    bnotes.place(relwidth=0.15,relheight=0.04,relx=0.35,rely=0.20,anchor="n")
    
    btextbook=Button(frame5,text="textbook",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:textbook.textbook(window,frame1))
    btextbook.place(relwidth=0.15,relheight=0.04,relx=0.5,rely=0.20,anchor="n")
    
    bquestionpaper=Button(frame5,text="questionpaper",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:questionpapers.questionpapers(window,frame1))
    bquestionpaper.place(relwidth=0.15,relheight=0.04,relx=0.65,rely=0.20,anchor="n")
    
    bsyllabus=Button(frame5,text="syllabus",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:syllabus.syllabus(window,frame1))
    bsyllabus.place(relwidth=0.15,relheight=0.04,relx=0.8,rely=0.20,anchor="n")
    
    pnt1()
    
    blogout=Button(frame5,text="logout",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=logout)
    blogout.place(relwidth=0.05,relheight=0.04,relx=0.95,rely=0.05,anchor="n")
    
    brefresh=Button(frame5,text="refresh",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:pnt10(window,frame1))
    brefresh.place(relwidth=0.05,relheight=0.04,relx=0.05,rely=0.05,anchor="n")
    
    lsubcode=Label(frame5,text="subcode",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
    lsubcode.place(relwidth=0.08,relheight=0.03,relx=0.04,rely=0.36,anchor="n")
    entry1=Entry(frame5)
    entry1.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.36,anchor="n")
    entry1.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15))
                     
    lsem=Label(frame5,text="sem",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
    lsem.place(relwidth=0.08,relheight=0.03,relx=0.04,rely=0.40,anchor="n")
    entry2=Entry(frame5)
    entry2.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.40,anchor="n")
    entry2.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15))
                     
    lbranch=Label(frame5,text="branch",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
    lbranch.place(relwidth=0.08,relheight=0.03,relx=0.04,rely=0.44,anchor="n")
    entry3=Entry(frame5)
    entry3.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.44,anchor="n")
    entry3.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15))
                     
    lsubjectname=Label(frame5,text="subject name",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
    lsubjectname.place(relwidth=0.08,relheight=0.03,relx=0.04,rely=0.48,anchor="n")
    entry4=Entry(frame5)
    entry4.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.48,anchor="n")
    entry4.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15))
                     
    lschema=Label(frame5,text="schema",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
    lschema.place(relwidth=0.08,relheight=0.03,relx=0.04,rely=0.52,anchor="n")
    entry5=Entry(frame5)
    entry5.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.52,anchor="n")
    entry5.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15))
    
    binsert=Button(frame5,text="upload",background="#005fff",foreground="white",font=("Times New Roman",15),command=insert)
    binsert.place(relwidth=0.05,relheight=0.04,relx=0.12,rely=0.56,anchor="n")
    
    
    
    frame5.mainloop()