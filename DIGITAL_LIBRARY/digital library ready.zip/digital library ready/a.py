from tkinter.ttk import *
from tkinter import *
from PIL import ImageTk,Image
from tkinter import filedialog
from tkinter import messagebox
from openpyxl import Workbook
from openpyxl import load_workbook
import os 
import numpy as np 

import pyttsx3

import anotes as notes

import asubject as subject

import atextbook as textbook

import aquestionpapers as questionpapers

import asyllabus as syllabus

#frame1 2
window=Tk()

widthvalue=window.winfo_screenwidth()
heightvalue=window.winfo_screenheight()

window.geometry('%dx%d'%(widthvalue,heightvalue))
window.title("DIGITAL LIBRARY ADMIN PANEL")


                                 
frame1=Frame(window)
frame1.place(relwidth=1,relheight=1)

img1=ImageTk.PhotoImage(Image.open("index1.png"))
limg1=Label(frame1,image=img1)
limg1.place(relwidth=1,relheight=1)

def voice(text):
    engine=pyttsx3.init()
    engine.setProperty('rate',120)#speed
    engine.setProperty('volume',0.9)
    voices=engine.getProperty('voices')
    engine.setProperty('voice',voices[1].id)
    engine.say(text)
    engine.runAndWait()
                 
def all1():

    frame2=Frame(window)
    frame2.place(relwidth=1,relheight=1)
    
    img2=ImageTk.PhotoImage(Image.open("b1.jpg"))
    limg2=Label(frame2,image=img2)
    limg2.place(relwidth=1,relheight=1)
    
    lheader1=Label(frame2, text="WELCOME TO DIGITAL LIBRARY ADMIN PANEL", font=("Times New Roman",30), relief="solid")
    lheader1.place(relx=0.5,rely=0.06,anchor="n")
        
    bsubject=Button(frame2,text="subject",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:subject.subject(window,frame1))
    bsubject.place(relwidth=0.15,relheight=0.04,relx=0.2,rely=0.28,anchor="n")
    
    bnotes=Button(frame2,text="notes",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:notes.notes(window,frame1))
    bnotes.place(relwidth=0.15,relheight=0.04,relx=0.35,rely=0.28,anchor="n")
    
    btextbook=Button(frame2,text="textbook",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:textbook.textbook(window,frame1))
    btextbook.place(relwidth=0.15,relheight=0.04,relx=0.5,rely=0.28,anchor="n")
    
    bquestionpaper=Button(frame2,text="questionpaper",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:questionpapers.questionpapers(window,frame1))
    bquestionpaper.place(relwidth=0.15,relheight=0.04,relx=0.65,rely=0.28,anchor="n")
    
    bsyllubus=Button(frame2,text="syllabus",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:syllabus.syllabus(window,frame1))
    bsyllubus.place(relwidth=0.15,relheight=0.04,relx=0.8,rely=0.28,anchor="n")
    
    
    
    frame2.mainloop()
    

def verify():
    
    a=entry1.get() 
    b=entry2.get()
    
    if(a=="" and  b==""):
        lincorrect3=Label(frame1,text="enter valid credentials",background="yellow",foreground="black",font=("Glasgow Heavy",15),relief="ridge")
        lincorrect3.place(relwidth=0.2,relheight=0.05,relx=0.5,rely=0.6,anchor="n")
        voice("please enter valid credentials")
        
    
    elif(a=="shree" and b=="12345"):       
        messagebox.showinfo("digital library admin panel","successful login")
        entry1.delete(0,END)
        entry2.delete(0,END)
        all1()
        
    elif(a!="shree"):
        lincorrect1=Label(frame1,text="username is incorrect",background="yellow",foreground="black",font=("Glasgow Heavy",15),relief="ridge")
        lincorrect1.place(relwidth=0.2,relheight=0.05,relx=0.5,rely=0.6,anchor="n")
        entry1.delete(0,END)
        entry2.delete(0,END)
        voice("access denied username is incorrect")
        
    elif(b!="12345" and a=="shree"):
        lincorrect2=Label(frame1,text="password is incorrect",background="yellow",foreground="black",font=("Glasgow Heavy",15),relief="ridge")
        lincorrect2.place(relwidth=0.2,relheight=0.05,relx=0.5,rely=0.6,anchor="n")
        entry1.delete(0,END)
        entry2.delete(0,END)
        voice("access denied password is incorrect")

 
    

lheader1=Label(frame1, text="WELCOME TO DIGITAL LIBRARY ADMIN PANEL", font=("Times New Roman",30), relief="solid")
lheader1.place(relx=0.5,rely=0.06,anchor="n")

lheader2=Label(frame1, text="ADMIN LOGIN", font=('Noto Serif',20), relief="solid")
lheader2.place(relx=0.5,rely=0.27,anchor="n")

louterbox=Label(frame1,width=60,height=10,relief="solid")
louterbox.place(relwidth=0.29,relheight=0.13,relx=0.5,rely=0.35,anchor="n")

luser=Label(frame1,text="USERNAME",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
luser.place(relwidth=0.075,relheight=0.05,relx=0.4,rely=0.36,anchor="n")

entry1=Entry(frame1)
entry1.place(relwidth=0.20,relheight=0.05,relx=0.54,rely=0.36,anchor="n")
entry1.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15))

lpassword=Label(frame1,text="PASSWORD",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
lpassword.place(relwidth=0.075,relheight=0.05,relx=0.4,rely=0.42,anchor="n")

entry2=Entry(frame1)
entry2.place(relwidth=0.20,relheight=0.05,relx=0.54,rely=0.42,anchor="n")
entry2.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15),show="*")

blogin=Button(frame1,text="LOGIN",background="#005fff",foreground="white",font=("Times New Roman",15),command=verify)
blogin.place(relwidth=0.05,relheight=0.05,relx=0.5,rely=0.49,anchor="n")

blogin=Button(frame1,text="LOGIN WITH FACE ID",background="#005fff",foreground="white",font=("Times New Roman",15))
blogin.place(relwidth=0.13,relheight=0.05,relx=0.5,rely=0.54,anchor="n")


window.mainloop()