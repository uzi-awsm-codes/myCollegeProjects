from tkinter.ttk import *
from tkinter import *
from PIL import ImageTk,Image
from tkinter import filedialog

import shutil
from tkinter import messagebox
from openpyxl import Workbook
from openpyxl import load_workbook
import os
import pymysql

from tkinter.filedialog import askopenfilename


#frame7 6

import asubject as subject

import atextbook as textbook

import anotes as notes

import asyllabus as syllabus

  
def pnt10(window,frame1):
    questionpapers(window,frame1)

def frame(frame7)  :
    frame7.tkraise()
      
def questionpapers(window,frame1):
    
    def insert(z):
        a=entry1.get()
        b=entry2.get()
        c=entry3.get()
       
        
        conn=pymysql.connect(host="localhost",user="root",password="",db="digital_library")
        cursor=conn.cursor()
        sql="INSERT INTO questionpapers(subcode,year,month,questionpapers) values(%s,%s,%s,%s)"
        cursor.execute(sql,(a,b,c,"uploaded_pdf"+"/"+str(z[-1])))
        conn.commit()
        entry2.delete(0,END)
        entry2.delete(0,END)
        entry3.delete(0,END)
        pnt10(window,frame1)
        
    
    def logout():
        frame1.tkraise()
    
    frame7=Frame(window)
    frame7.place(relwidth=1,relheight=1)
    
    def delete(a):
                
                a1=a[0]
                a2=a[1]
                a3=a[2]
                a4=a[3]
                conn=pymysql.connect(host="localhost",user="root",password="",db="digital_library")
                cursor=conn.cursor()
                sql="delete from questionpapers where subcode=(%s) and year=(%s) and month=(%s) and questionpapers=(%s) ;"
                cursor.execute(sql,(a1,a2,a3,a4))
                conn.commit()
                pnt10(window,frame1)
    def view(a):
        a4=a[3]
        os.startfile("C:\\xampp\\htdocs\\1\\digital library complete\\"+str(a4))
                    
            
    def pnt1():
        
            lsubcode=Label(frame7,text="subcode",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
            lsubcode.place(relwidth=0.1,relheight=0.03,relx=0.35,rely=0.27,anchor="n")
            
            lfaculty=Label(frame7,text="year",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
            lfaculty.place(relwidth=0.1,relheight=0.03,relx=0.45,rely=0.27,anchor="n")
            
            lcollege=Label(frame7,text="month",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
            lcollege.place(relwidth=0.1,relheight=0.03,relx=0.55,rely=0.27,anchor="n")
            
            lnotes=Label(frame7,text="question paper",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
            lnotes.place(relwidth=0.1,relheight=0.03,relx=0.65,rely=0.27,anchor="n")
            
            conn=pymysql.connect(host="localhost",user="root",password="",db="digital_library")
            cursor=conn.cursor()
            sql="select * from questionpapers;"
            cursor.execute(sql)
            d=cursor.fetchall()

            conn.commit()
            le=len(d)
            if le<=15:
                l=0           
                for i in range(le):
                    for j in range(4):
                        lsubcode=Label(frame7,text=d[i][j],background="black",foreground="white",width=10,font=("Glasgow Heavy",12),relief="ridge")
                        lsubcode.place(relwidth=0.1,relheight=0.03,relx=0.35+(j*0.1),rely=0.3+(i*0.03),anchor="n")
                    l=l+1
                if l!=0: 
                    bdelete=Button(frame7,text="delete",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",12),relief="ridge",command=lambda:delete(d[l-1]))
                    bdelete.place(relwidth=0.05,relheight=0.03,relx=0.725,rely=0.3+((l-1)*0.03),anchor="n")
                    bview=Button(frame7,text="view",background="#005fff",foreground="white",width=23,font=("Glasgow Heavy",12),relief="ridge",command=lambda:view(d[l-1]))
                    bview.place(relwidth=0.05,relheight=0.03,relx=0.77,rely=0.3+((l-1)*0.03),anchor="n")
                        
            else:
                for i in range(le):
                    for j in range(4):
                        
                        def next1(k):
                            
                            
                            frame6=Frame(window)
                            frame6.place(relwidth=0.6,relheight=0.5,relx=0.25,rely=0.3)
                            
                            img5=ImageTk.PhotoImage(Image.open("b1.jpg"))
                            limg5=Label(frame6,image=img5)
                            limg5.place(relwidth=1,relheight=1)
                            l=0
                            m=le-k
                            for i in range((le-k),le):
                                m=m+1
                                l=l+1
                                
                                for j in range(4):
                                     lsubcode=Label(frame6,text=d[i][j],background="black",foreground="white",width=20,font=("Glasgow Heavy",12),relief="ridge")
                                     lsubcode.place(relwidth=0.167,relheight=0.06,relx=0.17+(j*0.167),rely=0.00+((i-15)*0.06),anchor="n")
                                     bback=Button(frame6,text="back",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",12),relief="ridge",command=lambda:frame(frame7))
                                     bback.place(relwidth=0.167,relheight=0.06,relx=0.5,rely=0.94,anchor="n")
                
                            if m!=0:
                                bdelete=Button(frame6,text="delete",background="#ff9f00",foreground="white",width=10,font=("Glasgow Heavy",12),relief="ridge",command=lambda:delete(d[m-1]))
                                bdelete.place(relwidth=0.1,relheight=0.06,relx=0.805,rely=0.00+((l-1)*0.06),anchor="n")  
                                bview=Button(frame6,text="view",background="#005fff",foreground="white",width=23,font=("Glasgow Heavy",12),relief="ridge",command=lambda:view(d[m-1]))
                                bview.place(relwidth=0.1,relheight=0.06,relx=0.9,rely=0.00+((l-1)*0.06),anchor="n")
                            frame6.mainloop()
                            
                        if i<15:
                            lsubcode=Label(frame7,text=d[i][j],background="black",foreground="white",width=10,font=("Glasgow Heavy",12),relief="ridge")
                            lsubcode.place(relwidth=0.1,relheight=0.03,relx=0.35+(j*0.1),rely=0.3+(i*0.03),anchor="n")
                            bnext=Button(frame7,text="next",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",12),relief="ridge",command=lambda:next1(le-15))
                            bnext.place(relwidth=0.1,relheight=0.03,relx=0.5,rely=0.75,anchor="n")




    
                   
    img4=ImageTk.PhotoImage(Image.open("b1.jpg"))
    limg4=Label(frame7,image=img4)
    limg4.place(relwidth=1,relheight=1)
    
    lheader1=Label(frame7, text="WELCOME TO DIGITAL LIBRARY ADMIN PANEL", font=("Times New Roman",30), relief="solid")
    lheader1.place(relx=0.5,rely=0.06,anchor="n")
    
    
    bsubject=Button(frame7,text="subject",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:subject.subject(window,frame1))
    bsubject.place(relwidth=0.15,relheight=0.04,relx=0.2,rely=0.20,anchor="n")
    
    bnotes=Button(frame7,text="notes",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:notes.notes(window,frame1))
    bnotes.place(relwidth=0.15,relheight=0.04,relx=0.35,rely=0.20,anchor="n")
    
    btextbook=Button(frame7,text="textbook",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:textbook.textbook(window,frame1))
    btextbook.place(relwidth=0.15,relheight=0.04,relx=0.5,rely=0.20,anchor="n")
    
    bquestionpaper=Button(frame7,text="questionpaper",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=pnt1)
    bquestionpaper.place(relwidth=0.15,relheight=0.04,relx=0.65,rely=0.20,anchor="n")
    
    bsyllabus=Button(frame7,text="syllabus",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:syllabus.syllabus(window,frame1))
    bsyllabus.place(relwidth=0.15,relheight=0.04,relx=0.8,rely=0.20,anchor="n")
    
    pnt1()


    
    blogout=Button(frame7,text="logout",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=logout)
    blogout.place(relwidth=0.05,relheight=0.04,relx=0.95,rely=0.05,anchor="n")
    
    brefresh=Button(frame7,text="refresh",background="#ff9f00",foreground="white",width=23,font=("Glasgow Heavy",15),relief="ridge",command=lambda:pnt10(window,frame1))
    brefresh.place(relwidth=0.05,relheight=0.04,relx=0.05,rely=0.05,anchor="n")
  
    
    
    lsubcode=Label(frame7,text="subcode",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
    lsubcode.place(relwidth=0.08,relheight=0.03,relx=0.04,rely=0.36,anchor="n")
    entry1=Entry(frame7)
    entry1.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.36,anchor="n")
    entry1.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15))
                     
    lfaculty=Label(frame7,text="year",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
    lfaculty.place(relwidth=0.08,relheight=0.03,relx=0.04,rely=0.40,anchor="n")
    entry2=Entry(frame7)
    entry2.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.40,anchor="n")
    entry2.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15))
                     
    lcollege=Label(frame7,text="month",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
    lcollege.place(relwidth=0.08,relheight=0.03,relx=0.04,rely=0.44,anchor="n")
    entry3=Entry(frame7)
    entry3.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.44,anchor="n")
    entry3.configure(background="#7c7c7c",foreground="white",relief="solid",font=("Glasgow Heavy",15))
                     
    lnotes=Label(frame7,text="questionpa..",background="yellow",foreground="black",width=10,font=("Glasgow Heavy",15),relief="ridge")
    lnotes.place(relwidth=0.08,relheight=0.03,relx=0.04,rely=0.48,anchor="n")
    

                  
    def pnt4():
        global z
        file=askopenfilename()
        shutil.copy(file,"C:\\xampp\\htdocs\\1\\digital library complete\\uploaded_pdf")
        z=file.split("/")
        lfile=Label(frame7,text=z[-1],background="#7c7c7c",foreground="white",font=("Glasgow Heavy",10),relief="ridge")
        lfile.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.48,anchor="n")
        
        
                        
    bbrowse=Button(frame7,text="BROWSE",background="#7c7c7c",foreground="white",font=("Glasgow Heavy",15),command=pnt4)
    bbrowse.place(relwidth=0.15,relheight=0.03,relx=0.16,rely=0.48,anchor="n")
    
    binsert=Button(frame7,text="upload",background="#005fff",foreground="white",font=("Times New Roman",15),command=lambda:insert(z))
    binsert.place(relwidth=0.05,relheight=0.04,relx=0.12,rely=0.52,anchor="n")
            
    frame7.mainloop()
    
    
    
